﻿var result = confirm("Want to delete?");
if (result) {
    //Logic to delete the item
}